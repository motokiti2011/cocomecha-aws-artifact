import json
import boto3

from datetime import datetime

from boto3.dynamodb.conditions import Key
# Keyオブジェクトを利用できるようにする

# Dynamodbアクセスのためのオブジェクト取得
dynamodb = boto3.resource('dynamodb')
# 指定テーブルのアクセスオブジェクト取得
slipDetailInfo = dynamodb.Table("slipDetailInfo")
salesServiceInfo = dynamodb.Table("salesServiceInfo")
transactionSlip = dynamodb.Table("transactionSlip")
completionSlip = dynamodb.Table("completionSlip")


# 内部処理 引数に指定された操作で伝票の工程ステータス遷移処理を行う
def lambda_handler(event, context) :
  print("Received event: " + json.dumps(event))

  try:
    slipNo = event['slipNo']
    serviceType = event['serviceType']
    processStatus = event['processStatus']

    print('LABEL_1')
    # 対象伝票のステータスを更新する
    slip = moveProcessStatus(slipNo, serviceType, processStatus)
    if slip == None :
      print('moveprocess_Failure')
      return
    print('LABEL_2')
    return 200

  except Exception as e:
      print("Error Exception.")
      print(e)


# 対象の伝票情報を取得
def moveProcessStatus(slipNo, serviceType, processStatus):

  if serviceType == '0' :
    print('LABEL_3')
    return slipDitailStatusMove_query(slipNo, processStatus)
  else :
    print('LABEL_4')
    return salesServiceStatusMove_query(slipNo, processStatus)


# 伝票情報のステータス操作
def slipDitailStatusMove_query(slipNo, processStatus) :
  # 対象の伝票情報取得
  queryData = slipDetailInfo.query(
      KeyConditionExpression = Key("slipNo").eq(slipNo) & Key("deleteDiv").eq("0")
  )
  print('LABEL_5')
  items = queryData['Items']
  if len(items) == 0 :
    print('Not_Target_Slip')
    return None
  print('LABEL_6')
  slip = items[0]
  slip['processStatus'] = processStatus
  slip['updated'] = datetime.now().strftime('%x %X')
  print('LABEL_7')
  # ステータスを更新
  putResponse = slipDetailInfo.put_item(
    Item= slip
  )
  print('LABEL_8')
  # putResponse = slipDetailInfo.put_item(slip)

  if putResponse['ResponseMetadata']['HTTPStatusCode'] != 200:
    print('LABEL_9')
    print(putResponse)
    return None
  else:
    print('Post Successed.')
  print('LABEL_10')
  return slip


# サービス商品のステータス操作
def salesServiceStatusMove_query(slipNo, processStatus) :
  # 対象の伝票情報取得
  queryData = salesServiceInfo.query(
      KeyConditionExpression = Key("slipNo").eq(slipNo) & Key("deleteDiv").eq("0")
  )
  print('LABEL_11')
  items = queryData['Items']
  if len(items) == 0 :
    print('Not_Target_SalesService')
    return None
  print('LABEL_12')
  salesService = items[0]
  salesService['processStatus'] = processStatus
  salesService['updated'] = datetime.now().strftime('%x %X')
  print('LABEL_13')
  # ステータスを更新
  putResponse = slipDetailInfo.put_item(
    Item= salesService
  )
  print('LABEL_14')
  # putResponse = slipDetailInfo.put_item(salesService)

  if putResponse['ResponseMetadata']['HTTPStatusCode'] != 200:
    print('LABEL_15')
    print(putResponse)
    return None
  else:
    print('Post Successed.')
  print('LABEL_16')
  return salesService