import json
import boto3

from datetime import datetime

from boto3.dynamodb.conditions import Key
# Key�I�u�W�F�N�g�𗘗p�ł���悤�ɂ���

# Dynamodb�A�N�Z�X�̂��߂̃I�u�W�F�N�g�擾
dynamodb = boto3.resource('dynamodb')
# �w��e�[�u���̃A�N�Z�X�I�u�W�F�N�g�擾
slipDetailInfo = dynamodb.Table("slipDetailInfo")
salesServiceInfo = dynamodb.Table("salesServiceInfo")



# �`�[�Ǘ��҃`�F�b�N
def lambda_handler(event, context):
  print("Received event: " + json.dumps(event))

  OperationType = event['OperationType']

  try:
    if OperationType == 'ADMINIDCHECHK':
      slipNo = event['Keys']['slipNo']
      serviceType = event['Keys']['serviceType']
      adminId = event['Keys']['adminId']

      if serviceType == '0':
        # �F�؏��`�F�b�N�テ�[�U�[ID���擾
        # ����
        input_event = {
            "userId": adminId,
        }
        Payload = json.dumps(input_event) # json�V���A���C�Y
        # ���������ŌĂяo��
        response = boto3.client('lambda').invoke(
            FunctionName='CertificationLambda',
            InvocationType='RequestResponse',
            Payload=Payload
        )
        body = json.loads(response['Payload'].read())
        print(body)
        # ���[�U�[���̃��[�U�[ID���擾
        if body != None :
          userId = body
        else :
          print('NOT-CERTIFICATION')
          return

        return slipDetailInfo_query(slipNo, userId)

      elif serviceType == '1':
        return salesServiceInfoOffice_query(slipNo, adminId)

      elif serviceType == '2':
        return salesServiceInfoMecha_query(slipNo, adminId)

  except Exception as e:
      print("Error Exception.")
      print(e)

# ���R�[�h����
def slipDetailInfo_query(slipNo, adminId):
    queryData = slipDetailInfo.query(
        IndexName = 'slipAdminUserId-index',
        KeyConditionExpression = Key("slipAdminUserId").eq(adminId)
    )
    items=queryData['Items']
    print(items)
    return items

    if len(items) == 0:
      return []

    item = items[0]
    
    if item['slipNo'] == slipNo :
      return item
    else :
      return []


# ���R�[�h����
def salesServiceInfoOffice_query(slipNo, adminId):
    queryData = slipDetailInfo.query(
        IndexName = 'slipAdminOfficeId-index',
        KeyConditionExpression = Key("slipAdminOfficeId").eq(adminId) & Key("deleteDiv").eq("0")
    )
    items=queryData['Items']
    print(items)
    return items

    if len(items) == 0:
      return []

    item = items[0]
    
    if item['slipNo'] == slipNo :
      return item
    else :
      return []

# ���R�[�h����
def salesServiceInfoMecha_query(slipNo, adminId):
    queryData = slipDetailInfo.query(
        IndexName = 'slipAdminMechanic-index',
        KeyConditionExpression = Key("slipAdminMechanicId").eq(adminId) & Key("deleteDiv").eq("0")
    )
    items=queryData['Items']
    print(items)
    return items

    if len(items) == 0:
      return []

    item = items[0]
    
    if item['slipNo'] == slipNo :
      return item
    else :
      return []

